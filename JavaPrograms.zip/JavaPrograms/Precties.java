import java.util.*;
class Precties
{
public static void main(String []args)
{
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int i,j;
for(i=1;i<=a;i++)
{
for(j=1;j<=a;j++)
{
if(j<=i)
{
System.out.println("*");
}
else
{
System.out.println(" ");
}
}
System.out.println("\n");
}
}
}
