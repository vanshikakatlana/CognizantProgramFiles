import java.util.Scanner;

public class Tudip {
    public static void main(String[] args) {
        System.out.println("enter the num value");
        Scanner SC = new Scanner(System.in);
        int num = SC.nextInt();
        if (num > 41) {
            System.out.println("foo");
        }
        if (num > 43) {
            System.out.println("baar");
        }
        if (num > 41 && num > 43) {
            System.out.println("foobaar");
        }

    }

}
