import java.util.*;
class Van
{
int x,y;
Van(int p,int q)
{
x=p;
y=q;
System.out.println(x);
System.out.println(y);
}
}
class Van1 extends Van
{
Van1(int n)
{
super(5,7);
System.out.println(n);
}
public static void main(String []args)
{
Van1 v1=new Van1(3);
}
}