package p1;
 public class Nokia1
{
int mic;
int sem;
int camer;
public void Key(int x,int y,int z)
{
 mic=x;
 sem=y;
 camer=z;
}
 public void Display()
{
System.out.println(mic);
System.out.println(sem);
System.out.println(camer);
}
}