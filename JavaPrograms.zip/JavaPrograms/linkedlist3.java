public class linkedlist3 {
    int data;
    linkedlist3 nextNode;

    linkedlist3(int data) {
        this.data = data;
    }

    public static void main(String[] args) {
        linkedlist3 l1 = new linkedlist3(2);
        linkedlist3 l2 = new linkedlist3(3);
        linkedlist3 l3 = new linkedlist3(4);
        linkedlist3 l4 = new linkedlist3(5);
        l1.nextNode = l2;
        l2.nextNode = l3;
        l3.nextNode = l4;

    }

}
