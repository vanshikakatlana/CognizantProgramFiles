import java.util.*;
class Collection1
{
public static void main(String []args)
{
ArrayList a1=new ArrayList(5);
a1.add("A");
a1.add("B");
a1.add("C");
a1.add("D");
a1.add("E");
a1.add("Vanshika");
System.out.println(a1);
boolean remove=a1.remove("Vanshika");
System.out.println(a1);
System.out.println(remove);
boolean add=a1.add("Katlana");
System.out.println(add);
ArrayList l1=new ArrayList(3);
l1.add("a");
l1.add("b");
l1.add("c");
System.out.println(l1);
boolean removeAll=l1.removeAll(l1);
System.out.println(removeAll);
System.out.println(l1);
}
}