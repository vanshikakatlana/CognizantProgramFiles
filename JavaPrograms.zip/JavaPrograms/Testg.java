class Test
{
int i=10;
}

class Testg extends Test
{
int i=20;
void show(int i)
{
System.out.println(i);//30;
System.out.println(this.i);//20
System.out.println(super.i);//10
}
    public static void main(String []args)
    {
    Testg t1 = new Testg();
     t1.show(30);
    }
}