import java.util.*;

public class Tcs1 {
    public static void main(String[] args) {
        int[] arr = new int[100];
        int count = 1;
        Scanner SC = new Scanner(System.in);
        System.out.print("entre the array size=");
        int n = SC.nextInt();
        for (int i = 0; i < n; i++) {
            arr[i] = SC.nextInt();
        }
        int max = arr[0];
        for (int i = 0; i < n; i++) {
            if (arr[i] > max) {
                count++;
                max = arr[i];
            }
        }
        System.out.println(count);
    }
}
