import java.util.*;
class Vehicle
{
void drive()
{
System.out.println("not repairing a car");
}
}
class Car extends Vehicle
{
void drive()
{
System.out.println("Repairing a car");
}
{
public static void main(String []args)
{
Vehicle v1=new Vehicle();
v1.drive();
}
}
}