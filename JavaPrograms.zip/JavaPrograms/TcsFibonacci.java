import java.util.Scanner;

public class TcsFibonacci {
    public static void main(String[] args) {
        int n, a = -1, b = 1, c, sum = 0;
        System.out.print("enter the number of fibonacci series=");
        Scanner SC = new Scanner(System.in);
        n = SC.nextInt();
        for (int i = 1; i <= n; i++) {
            c = a + b;
            sum = sum + c;
            System.out.println(c);
            a = b;
            b = c;
        }
        System.out.print("sum=" + sum);

    }
}
