import java.util.Scanner;

public class TcsMediam {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int oddMediam = 0, evenMediam = 0, index1, index2, temp = 0;
        System.out.println("enter the array size=");
        int sizeOfArray = SC.nextInt();
        int arr[] = new int[sizeOfArray];
        for (int i = 0; i < sizeOfArray; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < sizeOfArray; i++) {
            for (int j = i + 1; j < sizeOfArray; j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        if (sizeOfArray % 2 == 0) {
            index1 = sizeOfArray / 2;
            index2 = sizeOfArray - 1 / 2;
            evenMediam = arr[index1] + arr[index2] / 2;
            System.out.println(evenMediam);

        }

        index1 = sizeOfArray / 2;
        oddMediam = arr[index1];
        System.out.println("Median of the odd-sized array: " + oddMediam);

    }
}
