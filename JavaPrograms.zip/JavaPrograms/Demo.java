import java.util.*;
class Object1
{
private static int x;
void f1()
{
x=5;
System.out.println(x);
}
}
class Demo 
{
public static void main(String[]args)
{
Object1 obj=new Object1();
obj.f1();
}
}