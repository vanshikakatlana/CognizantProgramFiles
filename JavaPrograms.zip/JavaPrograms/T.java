class T
{
public static void main(String[] args)
{
String s1="Vanshika";
String s2="Katlana";
System.out.println(s1+s2);
System.out.println(s1+s2+10);
System.out.println(s1+10+s2);
System.out.println(12+23+s1+s2);
}

}