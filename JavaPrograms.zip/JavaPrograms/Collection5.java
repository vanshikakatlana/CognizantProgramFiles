import java.util.*;
class Collection5
{
public static void main(String []args)
{
ArrayList a1= new ArrayList();
for(int i=1;i<=10;i++)
{
a1.add(i);
}
System.out.println(a1);

Iterator i1=a1.iterator();
while(i1.hasNext())
{
int g1=(int)i1.next();

if(g1==3)
{
i1.remove();
}
}
System.out.println(a1);
}
}