import java.util.Scanner;

public class TcsStringThreeInput {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.println("enter the three String");
        String s1 = SC.next();
        String s2 = SC.next();
        String s3 = SC.next();
        char[] ch1 = s1.toCharArray();
        char[] ch2 = s2.toCharArray();
        int i;
        for (i = 0; i < s1.length(); i++) {

            if (ch1[i] == 'a' || ch1[i] == 'A' || ch1[i] == 'e' || ch1[i] == 'E' || ch1[i] == 'i' || ch1[i] == 'I'
                    || ch1[i] == 'o' || ch1[i] == 'O' || ch1[i] == 'u'
                    || ch1[i] == 'U') {
                ch1[i] = '%';
            }
            System.out.print(ch1[i]);

        }
        for (i = 0; i < s2.length(); i++) {
            if (!(ch2[i] == 'a' || ch2[i] == 'A' || ch2[i] == 'e' || ch2[i] == 'E' || ch2[i] == 'i' || ch2[i] == 'I'
                    || ch2[i] == 'o' || ch2[i] == 'O' || ch2[i] == 'u'
                    || ch2[i] == 'U')) {
                ch2[i] = '#';
            }
            System.out.print(ch2[i]);
        }
        String s4 = s3.toUpperCase();
        System.out.print(s4);
    }

}
