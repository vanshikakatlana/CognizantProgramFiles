class AAA
{
public static void main(String[] args)
{
String s1="Vanshika";
String s2="Katlana";
if(s1.equalsIgnoreCase(s2))
{
System.out.println(true);
}
else
{
System.out.println(false);
}
}
}