class Vehicle
{
void drive()
{
System.out.println("not repairing a car");
}
public static void main(String []args)
{
Car c1=new Car();
c1.drive();
}
}
class Car extends Vehicle
{
void drive()
{
System.out.println("Repairing a car");
}
}