class Compare
{
public static void main(String[] args)
{
String s1="";
String s2="Ab";
System.out.println(s1.compareTo(s2));
}
}