import java.util.*;
class Nokia1
{
 private int x,y;
 Nokia1(int p,int q)
{
x=p;
y=q;
System.out.println(x);
System.out.println(y);
} 
}
class Nokia2 extends Nokia1
{
Nokia2()
{
super(4,7);
{
System.out.println("inheritance with constructor");
}
}
}
class Inherit
{
public static void main(String []args)
{
Nokia2 n2=new Nokia2();
}
}