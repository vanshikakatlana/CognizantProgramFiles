class Main {
    private void privateMethod() {
        System.out.println("private method is call");
    }

    public void accessPrivateMethod() {
        privateMethod();
    }

}

public class privateMethod {
    public static void main(String[] args) {

        Main m1 = new Main();
        m1.accessPrivateMethod();
    }

}
