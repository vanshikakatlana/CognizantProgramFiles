import java.util.*;

public class TcsOddCount {
    public static void main(String[] args) {
        System.out.print("enter the value=");
        Scanner SC = new Scanner(System.in);
        int value = SC.nextInt();
        int count = 0;
        char[] arr = new char[value];
        for (char i = 0; i < value; i++) {
            arr[i] = SC.next().charAt(0);
        }
        for (int i = 0; i < value; i++) {
            for (int j = 0; j < value; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                }
            }
            if (count % 2 != 0) {
                System.out.println(arr[i] + " " + "colour balloon is present odd number of times in the bunch.");
                return;

            }
        }
        System.out.println("ALL are even");
    }
}
