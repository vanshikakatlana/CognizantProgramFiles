import java.util.*;

public class TcsPalindromeString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String Str = SC.nextLine().toUpperCase();
        System.out.println(Str);
        StringBuffer s1 = new StringBuffer();
        s1.append(Str);
        s1.reverse();
        String s3 = s1.toString();

        if (Str.equals(s3)) {
            System.out.println("palindroneString");
        } else {
            System.out.println("not palindroneString");
        }
    }
}
