import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Register extends JFrame
{ 
JLabel l1;
Register(String s1)
{
super(s1);
}
Register ()
{

}
void setComponents()
{
Font f1=new Font("Arial", Font.PLAIN, 30);
JLabel l1=new JLabel("REGISTER FORM");
setLayout(null);
l1.setFont(f1);
l1.setBounds(500,30,300,50);
l1.setForeground(Color.BLACK);
add(l1);
}
public static void main(String []args)
{
Register r1=new Register("Register Form");
r1.setSize(700,700);
r1.setVisible(true);
r1.setComponents();
r1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
