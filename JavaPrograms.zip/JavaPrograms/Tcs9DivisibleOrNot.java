import java.util.Scanner;

public class Tcs9DivisibleOrNot {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the number=");
        int number = SC.nextInt();
        if (number >= 100 && number <= 999)
            if (number % 9 == 0) {
                System.out.print("Number" + " " + number + " " + "is divisible by 9");
            } else {
                System.out.print("Number" + " " + number + " " + "is not divisible by 9");
            }
    }

}
