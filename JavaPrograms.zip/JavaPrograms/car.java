import java.util.*;
class Vehicle
{
void drive()
{
System.out.println("not repairing a car");
}
}
class car extends Vehicle
{
void drive()
{
System.out.println("Repairing a car");
}
public static void main(String []args)
{
car c1=new car();
c1.drive();
}
}
