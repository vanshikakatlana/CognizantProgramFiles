import java.util.*;

public class CollectionList {
    public static void main(String[] args) {
        /*
         * List<String> List1 = Arrays.asList("Monday", "Tuesday");
         * List1.set(0, null);
         * System.out.println(List1);
         * List<String> List2 = new ArrayList<>(List1);
         * List2.add("wansday");
         * List2.add("thasday");
         * System.out.println(List2);
         */
        List<Integer> li = new ArrayList<>();
        li.add(1);
        li.add(4);
        li.add(2);
        li.add(7);
        li.add(3);
        Collections.sort(li);
        System.out.println(li);
    }

}
