class multipleInterfaces implements Interface1, Interface2 {

}
