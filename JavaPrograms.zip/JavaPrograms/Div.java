package pack2;
import pack1.Amit;
class Div
{
public static void main(String []args)
{
Scanner SC=new Scanner(System.in);
int x=SC.nextInt();
int y=SC.nextInt();
{
  Amit a1=new Amit();
  a1.setData(x,y);

  a1.Display();
}
}
}