import java.util.*;
class Exceptionh2
{
public static void main(String []args)
{
Scanner SC=new Scanner(System.in);
int cd= SC.nextInt();
int wd= SC.nextInt();
try
{
if(cd<wd)
{
throw new ArithmeticException("INSAFISENT BALANCE");
}
cd=cd-wd;
System.out.println("Transtion is successfull!");
System.out.println("Currant balance is= "+cd);
}
catch(ArithmeticException e1)
{
System.out.println(e1.getMessage());
System.out.println("Currant balance is= "+cd);
}
finally
{
System.out.println("Thank you!!....");
}
}
}