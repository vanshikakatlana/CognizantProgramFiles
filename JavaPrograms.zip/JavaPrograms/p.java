import java.util.*;
class Example
{
public static void main()
{
System.out.println("a");
}
public static void main(int x)
{
System.out.println(x);
}
}
class p
{
public static void main(String []args)
{
System.out.println("vanshika");
 Example e1=new Example();
e1.main();
e1.main(5);
}
}

