class String1 {
    public static void main(String[] args) {

        String s1 = new String("vanshika");
        String s2 = new String("vanshika");
        System.out.println(s1);
    }
}