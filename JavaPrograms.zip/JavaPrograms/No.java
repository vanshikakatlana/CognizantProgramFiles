package p2;
import p1.Nokia1;
class No 
{
public static void main(String []args)
{
Nokia1 n1=new Nokia1();
n1.Key(7,5,9);
n1.Display();
}
}