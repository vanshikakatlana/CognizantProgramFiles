import java.util.Scanner;

public class TcsSeries {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int nth = SC.nextInt(); // Read the input nth value

        int term = 7; // First term is 0
        int prevTerm = 0;
        int result; // To store the previous term (needed for even positions)

        for (int i = 1; i < nth / 2 + 1; i++) {

            result = term * prevTerm;
            System.out.print(result + " " + (result - prevTerm) + " ");
            prevTerm++;

        }
        result = term * prevTerm;
        System.out.println("15th element of the series is = " + result);

    }
}
