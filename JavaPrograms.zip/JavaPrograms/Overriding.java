import java.util.*;
class Example
{
int x,y,z;
void f1(int a,int b)
{
 z=x+y;
}
void Display()
{
System.out.println(z);
}
}

class Example1 extends Example
{
void f1(int a,int b)
{
z=x+y;
}
void Display()
{
System.out.println(z);
}
}
class Overriding
{
public static void main(String []args)
{
Example1 e1=new Example1();
e1.f1(8,5);
e1.Display();
}
}