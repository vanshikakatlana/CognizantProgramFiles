import java.util.*;
public class naturaln
{
public static void main(String[]args)
{
Scanner Sc=new Scanner(System.in);
int n=Sc.nextInt();
for(int i=0;i<=n;i++)
{
System.out.println(i);
}
}
}