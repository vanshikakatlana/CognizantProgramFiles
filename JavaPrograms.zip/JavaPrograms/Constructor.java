import java.util.*;
class Demo
{
int x,y,z;
void f1()
{
System.out.println("vanshika");
}
Demo()
{
x=4;
y=7;
z=x+y;
System.out.println(z);
}
}
class Constructor
{
public static void main(String []args)
{
Demo d1=new Demo();
d1.f1();
}
}
