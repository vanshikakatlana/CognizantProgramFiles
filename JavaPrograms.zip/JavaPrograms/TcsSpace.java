import java.util.Scanner;

public class TcsSpace {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the String:");
        String string = sc.nextLine();

        StringBuffer sb = new StringBuffer(string);
        // output icodeinpython

    }

}
