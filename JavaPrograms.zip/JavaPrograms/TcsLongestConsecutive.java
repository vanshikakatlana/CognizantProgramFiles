import java.util.*;

public class TcsLongestConsecutive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter the array size=");
        int sizeOfArray = sc.nextInt();
        System.out.print("enter the array element=");
        int arr[] = new int[sizeOfArray];
        for (int i = 0; i < sizeOfArray; i++) {
            arr[i] = sc.nextInt();
        }
        int no = 0, long_l = 0;
        HashSet<Integer> hs = new HashSet<>();
        for (int i = 0; i < sizeOfArray; i++) {
            hs.add(arr[i]);
        }
        for (int i = 0; i < sizeOfArray; i++) {
            if (!hs.contains(arr[i] - 1)) {
                no = arr[i];

                while (hs.contains(no)) {

                    no++;
                }
                if (long_l < no - arr[i]) {
                    long_l = no - arr[i];
                }
            }
        }
        System.out.println("longest_consecutive" + long_l);

    }
}
