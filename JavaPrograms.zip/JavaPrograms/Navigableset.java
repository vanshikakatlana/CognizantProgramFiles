import java.util.*;
class Navigableset
{
public static void main(String []args)
{
TreeSet t1=new TreeSet();
t1.add(4);
t1.add(2);
t1.add(1);
t1.add(5);
t1.add(7);
t1.add(9);
t1.add(8);
t1.add(10);
t1.add(3);
t1.add(6);
System.out.println(t1.ceiling(5));
System.out.println(t1.floor(11));
System.out.println(t1.pollFirst());
System.out.println(t1.pollLast());
System.out.println(t1);
}
}





<?xml version="1.0" encoding="UTF-8""?>
<web-app xmlns :xsi="https://jakarta.ee/xml/ns/jakartaee" ;
	xmlns="https://jakarta.ee/xml/ns/jakartaee" xsi
	:schemaLocation="https://jakarta.ee/xml/ns/jakartaee https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd"
	id="WebApp_ID" version="6.0">
<servlet>
<servlet-name>myservlet</servlet-name>
<servlet-class>in.sp.backend.Myservlet</servlet-class>
</servlet>
<servlet-mapping>
<servlet-name>myservlet</servlet-name>
<url-pattern>/aaa</url-pattern>
</servlet-mapping>
</web-app>