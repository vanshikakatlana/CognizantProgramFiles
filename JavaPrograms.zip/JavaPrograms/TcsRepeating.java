import java.util.*;

public class TcsRepeating {
    public static void main(String[] args) {
        System.out.print("enter the array size=");
        Scanner SC = new Scanner(System.in);
        int n = SC.nextInt();
        int arr[] = new int[n];

        HashSet<Integer> h1 = new HashSet<>();

        for (int i = 0; i < n; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    h1.add(arr[j]);

                }

            }
        }
        System.out.println("sss" + h1);

    }
}
