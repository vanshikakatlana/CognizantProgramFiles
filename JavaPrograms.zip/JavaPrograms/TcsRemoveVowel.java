import java.util.Scanner;

public class TcsRemoveVowel {
    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        String newString = Scan.nextLine();
        String s2 = "";
        String s1 = newString.replaceAll("[aeiou]", "");
        System.out.println(s1);
    }

}
