import java.util.Scanner;

public class TcsNonRepeatingString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("Enter the String:");
        String string = SC.nextLine();
        for (int i = 0; i < string.length(); i++) {
            boolean flag = false;
            for (int j = 0; j < string.length(); j++) {
                if (i != j && string.charAt(i) == string.charAt(j)) {
                    flag = true;
                    break;
                }

            }
            if (!flag) {
                System.out.print(string.charAt(i));
            }
        }

    }
}
