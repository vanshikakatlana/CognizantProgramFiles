import java.util.*;
class Linkedlist1
{
public static void main(String []args)
{
LinkedList l1=new LinkedList();
l1.addFirst(21);
l1.add(23);
l1.add(20);
l1.add(24);
l1.addLast(22);
l1.add(1,19);

System.out.println(l1.getFirst());
System.out.println(l1.get(1));;
System.out.println(l1.get(2));
System.out.println(l1.get(3));
System.out.println(l1.get(4));

System.out.println(l1.getLast());
}
}