import java.util.Scanner;

public class TcsCube {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int sum = 0;
        System.out.print("enter the start value=");
        int start = SC.nextInt();
        System.out.print("enter the last value=");
        int last = SC.nextInt();
        for (int i = start; i <= last; i++) {
            sum = sum + i * i * i;
        }
        System.out.println("sum=" + sum);
    }
}
