import java.util.*;
class A
{
int x,y;
void f1(int x,int y)
{
this.x=x;
this.y=y;
}
void f1()
{
System.out.println("VANSHIKA KATLANA");
}
void Display()
{ 
System.out.println(x);
System.out.println(y);
}

public static void main(String []args)
{
A a1=new A();
a1.f1(4,5);
a1.f1();
a1.Display();
}
}
