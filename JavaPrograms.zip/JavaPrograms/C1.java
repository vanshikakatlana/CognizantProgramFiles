import java.util.*;
interface Example
{ 
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int c=8;
void f1(); 
}
class Inter implements Example
{
 public void f1()
{
System.out.println("vanshika");
} 
}
class C1 
{
public static void main(String []args)
{
Example e1=new Inter();
e1.f1();
System.out.println(Example.a);
}
}
