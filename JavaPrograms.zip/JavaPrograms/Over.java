import java.util.*;
class Example
{
int x,y,z;
void f1(int a,int b)
{
 z=x+y;
}
void Display()
{
System.out.println(z);
}
}

class Example1 extends Example
{
int x,y,z;
void f1(int a,int b)
{
x=a;
y=b;
z=x+y;
}
void Display()
{
System.out.println(z);
}
}
class Over
{
public static void main(String []args)
{
Example e1=new Example();
e1.f1(8,5);
e1.Display();
}
}