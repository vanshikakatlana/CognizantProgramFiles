import java.util.*;
class Area
{
static void fun1()
{ 
System.out.println("Area");
}
 static void fun2()
{
System.out.println("area is large");
}
}
class xample
{  
 static void fun1()
{ 
System.out.println("A");
}
 static void fun2()
{
System.out.println("B");
}
public static void main(String[]args)
{
System.out.println("V");
Area.fun1();
Area.fun2();
fun1();
fun2();
}
}