import java.util.*;
class Example
{
int x,y,z;
void f1(int x,int y,int z)
{
this.x=x;
this.y=y;
this.z=z;
}
void Display()
{
System.out.println(x);
System.out.println(y);
System.out.println(z);
}
}
class Importan
{
public static void main(String []args)
{
Example e1=new Example();
e1.f1(23,45,56);
e1.Display();
}
}