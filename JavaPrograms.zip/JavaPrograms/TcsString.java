import java.util.*;

public class TcsString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("Enter the String=");
        String string = SC.nextLine();
        int j;
        StringBuffer ST = new StringBuffer();
        ST.append(string);
        ST.reverse();
        System.out.println(ST);
        String newString = string.replaceAll("[^a-zA-Z0-9]", "");
        System.out.println(newString);
        String neString1 = string.replaceAll(" ", "");
        System.out.println(neString1);
        int length = string.length();
        StringBuffer S = new StringBuffer();
        HashSet<Character> hs = new HashSet<>();

        for (j = 0; j < length; j++)

        {
            hs.add(string.charAt(j));
        }

        {

        }

    }
}
