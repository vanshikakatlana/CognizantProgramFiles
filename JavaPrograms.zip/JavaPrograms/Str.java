public class Str {
    public static void main(String[] args) {
        String s1 = new String("Vanshikakatlana");
        int n = s1.lastIndexOf("Vans", 1);
        System.out.println("index is" + n);
    }
}