class Aa
{
int a=10;
}
class Ba extends Aa
{
int a=20;
void show(int a)
{
System.out.println(a);
}
public static void main(String[] args)
{
Ba b1=new Ba();
b1.show(30);
}
 
}