import java.util.*;
class A
 {
 private int x;
  void f1()
{
   x=5;
   System.out.println(x);
}
  int y;
  void fun1()
{
  System.out.println("member function");
}
 }
  class Staticmember
 {
  public static void main(String[]args)
{
 System.out.println("this is running");
  A a1=new A();
  a1.fun1();
 a1.f1();
 a1.y=9;
 {
  System.out.println(a1.y);
 }
}
 }