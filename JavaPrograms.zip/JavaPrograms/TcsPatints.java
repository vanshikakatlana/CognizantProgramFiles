import java.util.Scanner;

public class TcsPatints {
    public static void main(String[] args) {
        int max_value = 20, sum = 0;
        Scanner SC = new Scanner(System.in);
        System.out.print("Enter the total patient=");
        int patient = SC.nextInt();
        int arr[] = new int[patient];
        if (max_value >= patient) {
            for (int i = 0; i < patient; i++) {
                arr[i] = SC.nextInt();
            }
            for (int i = 0; i < patient; i++) {
                if (arr[i] < 17 && arr[i] > 0) {
                    sum = sum + 200;
                } else if (arr[i] >= 17 && arr[i] <= 40) {
                    sum = sum + 400;
                } else if (arr[i] > 40 && arr[i] < 120) {
                    sum = sum + 300;
                }

            }

            System.out.println("Total income:" + sum);
        } else {
            System.out.println("INVALID INPUT");
        }
    }

}
