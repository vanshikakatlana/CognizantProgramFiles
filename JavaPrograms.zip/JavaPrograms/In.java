import java.util.*;
interface Example
{
int a=9;
void f1();
static void f2()
{
Scanner SC=new Scanner(System.in);
int x=SC.nextInt();
int y=SC.nextInt();
int z=SC.nextInt();
int n=x+y+z;
System.out.println("sum is "+n);
}
} 
class In 
{
public static void main(String []args)
{
Example.f2();
Example.a=11;
System.out.println(Example.a);
}
}