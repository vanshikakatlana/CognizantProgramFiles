import java.util.*;
class Collection6
{
public static void main(String []args)
{
LinkedList list=new LinkedList();
for(int i=1;i<=10;i++)
{
list.add(i);
}
System.out.println(list);

ListIterator l1=list.listIterator();
while(l1.hasNext())
{
 int g1=(int)l1.next();
}
System.out.println(list);
}
}
