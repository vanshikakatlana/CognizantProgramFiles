import java.util.Scanner;

public class TcsNth_Term {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("Enter the nth term number=");
        int number = SC.nextInt();
        int div = number / 2;
        int a = 1, b = 1;
        for (int i = 1; i < div; i++) {
            // System.out.print(a + " " + b + " ");
            a = a * 2;
            b = b * 3;
        }
        System.out.println(b);
    }

}
