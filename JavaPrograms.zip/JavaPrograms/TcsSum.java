import java.util.Scanner;

public class TcsSum {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the input=");
        int input = SC.nextInt();
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum = sum + (input * i);
        }
        System.out.print("total sum=" + sum);

    }

}
