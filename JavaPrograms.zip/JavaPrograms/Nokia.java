import java.util.*;
 class Nokia1
{
int mic;
int sem;
int camer;
}
class Nokia 
{
public static void main(String []args)
{
Scanner SC=new Scanner(System.in);
int mic=SC.nextInt();
  int sem=SC.nextInt();
int camer=SC.nextInt();
System.out.println("mic value is" + mic);
System.out.println("sem GB rengs is" + sem);
System.out.println("camer pxcl is" + camer);
}
}