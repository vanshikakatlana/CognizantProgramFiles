import java.util.*;
class Collection3
{
public static void main(String []args)
{
ArrayList a1=new ArrayList(10);
a1.add ("A");
a1.add ("B");
a1.add ("C");
a1.add ("D");
a1.add ("E");
a1.add ("F");
a1.add ("G");
a1.add ("H");
a1.add("A");
System.out.println(a1.indexOf("F"));
System.out.println(a1.get(2));
System.out.println(a1.lastIndexOf("A"));
System.out.println(a1.lastIndexOf("I"));
a1.remove(8);
System.out.println(a1);
System.out.println(list<int>subList(1,6));
Iterator g1=a1.iterator();

while(g1.hasNext())
{
String s1=(String)g1.next();
if(s1==("F"))
{
System.out.println(s1);

}
}
}
}