import java.util.*;
class Collection4
{
public static void main(String []args)
{
Vector v1=new Vector();
v1.addElement("Vanshika");
v1.addElement("Katlana");
v1.addElement("Teesha");
v1.addElement("Katlana");
v1.addElement("Aryan");
v1.addElement("Katlana");
System.out.println(v1);
 
Enumeration e=v1.elements();

while(e.hasMoreElements())
{
System.out.println(e.hasMoreElements());
String s1=(String)e.nextElement();
if(s1=="Vanshika")
{
System.out.println("she is helping natura");
}
System.out.println(s1);
}

}
}