import java.util.*;

public class TcsMapPair {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int s1;
        System.out.print("enter the pair value=");
        int pairNumber = SC.nextInt();
        Map<Integer, Integer> hmap = new Hashtable<>();
        for (int i = 0; i < pairNumber; i++) {
            int key = SC.nextInt();
            int value = SC.nextInt();
            hmap.put(key, value);

        }
        for (Map.Entry<Integer, Integer> entry : hmap.entrySet()) {
            int a = entry.getKey();// 1
            int b = entry.getValue();// 2

            // Check if the reverse pair (b, a) exists in the map
            if (hmap.containsKey(b) && hmap.get(b) == a) {// 2
                // If symmetric pair found, print it

                System.out.println("(" + b + ", " + a + ")");
            }
        }

    }
}
