import java.util.HashSet;
import java.util.Scanner;

public class TcsDupicate {
    public static void main(String[] args) {
        System.out.print("enter the array size=");
        Scanner SC = new Scanner(System.in);
        int n = SC.nextInt();
        int i;
        int arr[] = new int[n];
        for (i = 0; i < n; i++) {
            arr[i] = SC.nextInt();
        }
        HashSet<Integer> h1 = new HashSet<>();
        for (i = 0; i < n; i++) {
            h1.add(arr[i]);
        }
        System.out.println(h1 + " " + "size of new array=" + h1.size());
    }
}
