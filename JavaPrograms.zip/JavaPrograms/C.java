public class C
{
public static void main(String []args)
{
String s1=new String("Vanshikakatlana");
int n=indexOf('k');
System.out.println("index is"+n);
}
}