public class example
{
public static void main(string[]args)
{
Scanner sc=new Scranner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
int sum=a+b;
system.out.println(sum);
}
}