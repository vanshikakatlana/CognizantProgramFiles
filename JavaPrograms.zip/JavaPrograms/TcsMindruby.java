import java.util.Scanner;

public class TcsMindruby {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the array size=");
        int sizeOfArray = SC.nextInt();
        int temp = 0;
        System.out.print("enter the k value=");
        int k = SC.nextInt();
        System.out.print("enter the interation value=");
        int interation = SC.nextInt();

        int arr[] = new int[sizeOfArray];
        System.out.println("enter the array value");
        for (int i = 0; i < sizeOfArray; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < interation; i++) {
            for (int j = i; j < k - 1; j++) {
                if (arr[j] < arr[j + 1] && temp < arr[j + 1]) {
                    temp = arr[j + 1];

                } else if (arr[j] > arr[j + 1] && temp < arr[j]) {
                    temp = arr[j];
                }

            }
            System.out.println(temp);
            k++;
            temp = 0;

        }

    }
}
