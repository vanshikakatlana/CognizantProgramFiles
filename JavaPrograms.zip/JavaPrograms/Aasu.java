package p4;
import java.util.*;
import p3.Aman;
class Aasu
{
public static void main(String []args)
{
Aman a1=new Aman();
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int b=SC.nextInt();
a1.f1(a,b);
}
}