class A
{
void show()
{

System.out.println("i am class A");
}
void display()
{
System.out.prinltn("i am display method");
}
}
class B
{
void show()
{
System.out.println("i am class B");
}
}
class MainClass extends A,B
{
public static void main(String[] args)
{
MainClass m1=new MainClass();
m1.show();
m1.display();
}
}