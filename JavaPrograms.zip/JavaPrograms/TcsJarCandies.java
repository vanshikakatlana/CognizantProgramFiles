import java.util.Scanner;

public class TcsJarCandies {
    public static void main(String[] args) {
        int NUMBER_OF_CANDIES = 10, candies = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("enter the number=");
        int value = sc.nextInt();
        if (value >= 1 && value <= 5) {
            candies = NUMBER_OF_CANDIES - value;
            System.out.println("NUMBER OF CANDIES SOLD " + value);
            System.out.println("NUMBER OF CANDIES AVAILABLE " + candies);
        } else {
            System.out.println("INVALID INPUT");
            System.out.println("NUMBER OF CANDIES LEFT:" + NUMBER_OF_CANDIES);
        }
    }
}
