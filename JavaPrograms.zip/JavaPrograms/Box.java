import java.util.*;
class Usethiscase
{
 int x,y;
 public void set(int x,int y)
{
this.x=x;
this.y=y;
}
void f3()
{
System.out.println(x);
System.out.println(y);
}
}
class Example extends Usethiscase
{
int x,y,p,q;
void f1(int x,int y,int p,int q)
{
super.x=x;
super.y=y;
this.p=p;
this.q=q;
}
void f2()
{
System.out.println(super.x);
System.out.println(this.p);
System.out.println(super.y);
System.out.println(this.q);

}
}
class Box
{
public static void main(String []args)
{
Example e1=new Example();
e1.f1(12,13,11,10);
e1.f2();
}
}