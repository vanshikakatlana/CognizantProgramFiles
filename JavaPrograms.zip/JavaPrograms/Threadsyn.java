import java.util.*;
class Account
{
int bal;
Account(int b)
{
bal=b;
}
public boolean isSufficientBal(int w)
{
if(bal>w)
{
return true;
}
else
{
return false;
}
}
public void withdraw(int w,String g1)
{
bal=bal-w;
System.out.println(g1+" withdraw Successful");
System.out.println(g1+" Current Bal is "+bal);
}
}
class Customer implements Runnable
{
Account h1;
String name;
Customer(Account v1,String s1)
{
h1=v1;
name=s1;
}
public void run()
{
synchronized(h1)
{
Scanner SC=new Scanner(System.in);
System.out.println(name+" Enter Amount");
int amt=SC.nextInt();
if(h1.isSufficientBal(amt))
{
h1.withdraw(amt,name);
}
else 
{
System.out.println("Insufficient Balance");
}
}
}
}
class Threadsyn
{
public static void main(String []args)
{
Account a1=new Account(1000);
Customer c1=new Customer(a1,"vanshika");
Customer c2=new Customer(a1,"Aryan");
Thread t1=new Thread(c1);
Thread t2=new Thread(c2);
t1.start();
t2.start();
}
}