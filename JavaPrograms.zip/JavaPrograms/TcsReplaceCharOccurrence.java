import java.util.*;

public class TcsReplaceCharOccurrence {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String string = SC.nextLine();
        char replace = 't';
        int count = 1;

        for (int i = 0; i < string.length(); i++) {
            char ch = string.charAt(i);
            if (ch == replace) {
                string = string.replaceFirst(String.valueOf(replace), String.valueOf(count));
                count++;

            }

        }
        System.out.println(string);

    }

}
