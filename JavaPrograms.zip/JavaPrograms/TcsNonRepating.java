import java.util.*;

public class TcsNonRepating {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.println("enter the size of array");
        int sizeOfArray = SC.nextInt();
        System.out.println("enter the value of array");
        int arr[] = new int[sizeOfArray];
        for (int i = 0; i < sizeOfArray; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < sizeOfArray; i++) {
            boolean flag = false;
            for (int j = 0; j < sizeOfArray; j++) {// 1,2,-1,1,3,1;
                if (i != j && arr[i] == arr[j]) {
                    flag = true;
                    break;

                }
            }
            if (!flag) {
                System.out.print(arr[i]);

            }

        }

    }
}
