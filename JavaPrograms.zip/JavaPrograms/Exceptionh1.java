import java.util.*;
class Exceptionh1
{
public static void main(String []args)
{
int x,y,z;
Scanner SC=new Scanner(System.in);
x=SC.nextInt();
y=SC.nextInt();
String s1;
s1=null;
s1="gsdhfteygituhbvcxzsxqdctfvygu4b5hin6jbhugyvfctdrhxctfv5yjgub6khinl68jo8ibhugvyfc5thd4xr";
try
{
System.out.println(x/y);
}
catch(ArithmeticException e1)
{
System.out.println(e1.getMessage());
}
try
{
System.out.println(s1.length());
}
catch(NullPointerException n1)
{
System.out.println(n1.getMessage());
}
}
}
