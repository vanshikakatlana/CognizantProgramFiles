import java.util.*;
class Animal
{
void makeSound()
{
System.out.println("bark");
}
}
class Cat extends Animal
{
void makeSound()
{
System.out.println("mauu");
}
public static void main(String []args)
{
Cat c1=new Cat();
c1.makeSound();
}
}