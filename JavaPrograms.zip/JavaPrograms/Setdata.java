package p1;

public class Setdata
{
 try
{
System.out.println(a/b);
}
 catch(ArithmeticException e1)
{
System.out.println(e1.getMessage());
}
}
