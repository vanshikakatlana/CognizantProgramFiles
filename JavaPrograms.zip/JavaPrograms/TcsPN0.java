import java.util.Scanner;

public class TcsPN0 {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String S = SC.nextLine();
        int count1 = 0, count2 = 0;
        char[] arr = S.toCharArray();
        for (int i = 0; i < S.length(); i++) {
            if (arr[i] == '#') {
                count1++;
            } else if (arr[i] == '*') {
                count2++;
            }
        }
        System.out.println(count2 - count1);

    }
}
