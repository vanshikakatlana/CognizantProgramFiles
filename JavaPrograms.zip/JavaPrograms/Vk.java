import java.util.*;
interface van
{
int i=7;
void f1();
}
class Process1 implements van,Runnable
{
 public void f1()
{
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int b=SC.nextInt();
System.out.println("your are enter the number of place a "+a );
System.out.println("your are enter the number of place b "+b );
}
public void run()
{
int n;
for(n=0;n<=10;n++)
{
System.out.println("Process:"+n);
}
}
}
class Process2 implements Runnable
{
public void run()
{
int n;
for(n=11;n<=20;n++)
{
System.out.println("Process:"+n);
}
}
}
class Vk
{
public static void main(String []args)
{
Process1 p1=new Process1();
p1.f1();
System.out.println(van.i);
Process2 p2=new Process2();
Thread t1=new Thread(p1);
Thread t2=new Thread(p2);
t1.start();
t2.start();
}
} 