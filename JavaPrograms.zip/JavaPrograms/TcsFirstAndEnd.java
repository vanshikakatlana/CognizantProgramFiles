import java.util.Scanner;

public class TcsFirstAndEnd {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int temp = 0;
        System.out.print("enter the array size=");
        int n = SC.nextInt();
        int arr[] = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n / 2; j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }

        int div = arr.length / 2;

        for (int i = div; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }

        }
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }

    }
}
