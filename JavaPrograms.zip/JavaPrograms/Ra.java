import java.io.Console;

public class Ra {
    public static void main(String[] args) {
        int[] arr = { 1, 2, -1, 1, 3, 1, 4, 2, 1, 3, 5, -1 };

        System.out.println("Non-repeating values:");

        for (int i = 0; i < arr.length; i++) {
            boolean isRepeating = false;

            // Check if the current element repeats in the array
            for (int j = 0; j < arr.length; j++) {
                if (i != j && arr[i] == arr[j]) {
                    isRepeating = true;
                    break;
                }
            }

            // If the element does not repeat, print it
            if (!isRepeating) {
                System.out.println(arr[i]);
            }
        }
    }
}
