import java.util.*;
class Array
{ 
public static void main(String []args)
{
int a[]=new int[5];
for(int i=0;i<5;i++)
{
Scanner SC=new Scanner(System.in);
int b=SC.nextInt();
}
}
}