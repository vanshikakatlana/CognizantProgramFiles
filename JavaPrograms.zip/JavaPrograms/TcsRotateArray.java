import java.util.Scanner;

public class TcsRotateArray {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int temp = 0;
        System.out.print("enter the size of array=");
        int sizeOfArray = SC.nextInt();
        int arr[] = new int[sizeOfArray];
        for (int i = 0; i < sizeOfArray; i++) {
            arr[i] = SC.nextInt();
        }
        System.out.print("enter the number_of_Rotation=");
        int number_Of_Rotation = SC.nextInt();
        for (int i = 0; i < number_Of_Rotation; i++) {
            for (int j = sizeOfArray - 1; j > number_Of_Rotation - 1; j--) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        for (int i = 0; i < sizeOfArray; i++) {
            System.out.println(arr[i]);
        }

    }

}
