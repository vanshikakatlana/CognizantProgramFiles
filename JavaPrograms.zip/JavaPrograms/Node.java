public class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
    }

    public static void main(String[] args) {
        Node n1 = new Node(5);
        Node n = new Node(15);
        Node n2 = new Node(6);
        Node n3 = new Node(7);
        Node n4 = new Node(21);
        Node n5 = new Node(9);
        n1.next = n2;
        n1.next = n;// jo bad me connect hoga us ka address or value rkhega
        n2.next = n3;
        n3.next = n4;
        n4.next = n5;
        System.out.println(n1.next.data);
        System.out.println(n1.next.data);
        System.out.println(n2.next);
        System.out.println(n3.next);
        System.out.println(n4.next);
        System.out.println(n5.next);

        try {

            System.out.println(n1.next);
        } catch (Exception e1) {
            System.out.println();
        }

    }
}
