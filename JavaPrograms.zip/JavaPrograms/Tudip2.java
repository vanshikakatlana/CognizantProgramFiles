import java.util.Scanner;

public class Tudip2 {
    public static void main(String[] args) {
        int temp = 0;
        int arr[] = new int[100];
        System.out.println("enter the array size");
        Scanner SC = new Scanner(System.in);
        int size = SC.nextInt();
        for (int i = 0; i < size; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < size; i++) {
            for (int j = i + 1; j < size; j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        System.out.println("smallest number " + arr[0]);
    }
}
