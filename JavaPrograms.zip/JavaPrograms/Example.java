import java.util.*;
public class Example
{
public static void main(String[]args)
{
Scanner Sc=new Scanner(System.in);
int a=Sc.nextInt();
int b=Sc.nextInt();
int sum=a+b;
System.out.println(sum);
}
}