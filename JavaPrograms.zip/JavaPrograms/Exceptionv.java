import java.util.*;
class Exceptionv
{
public static void main(String []args)
{
System.out.println(5/0);
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int b=SC.nextInt();
try
{
System.out.println(a/b);
}
catch(Exception e1)
{
System.out.println("vanshika");
}
finally
{
System.out.println("Thank you!");
}
}
}