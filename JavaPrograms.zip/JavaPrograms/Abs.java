import java.util.*;
abstract class P
{
int x,y,z,a,b,c;
void f2()
{
Scanner SC=new Scanner(System.in);
a=SC.nextInt();
b=SC.nextInt();
c=a+b;
System.out.println("prent class sum is " +c);
}
abstract void f1();
}
class Abs extends P
{
String str;
void f1()
{
Scanner SC=new Scanner(System.in);
x=SC.nextInt();
y=SC.nextInt();
z=x+y;
System.out.println("child class sum is " +z);
}
void f3()
{
Scanner SC=new Scanner(System.in); 
System.out.println("plesae enter your name");
str=SC.nextLine();
System.out.println("name is  " +str);
}
public static void main(String []args)
{
Abs a1=new Abs();
a1.f1();
a1.f2();
a1.f3();
}
}