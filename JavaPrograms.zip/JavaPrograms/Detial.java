import java.util.*;
class Person
{
private int age;
private String name;
void f1(int x)
{
age=x;
System.out.println(x);
}
void f2(String n)
{
name=n;
System.out.println(n);
}
}
class Student extends Person
{
int rollno;
int phoneno;
void f3(int a)
{
rollno=a;
System.out.println(a);
}
void f4(int b)
{
phoneno=b;
System.out.println(b);
}
}
class Detial
{
public static void main(String []args)
{
Student s1=new Student();
s1.f2("vanshika");
s1.f1(19);
s1.f3(1829);
s1.f4(91795);
}
}