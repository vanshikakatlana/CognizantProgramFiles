import java.util.*;
class Pattern1
{
public static void main(String []args)
{
int i,j,b,c;
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
for(i=1;i<=a;i++)
{
 b=a-1;
 c=b+a;
for(j=1;j<=c;j++)
{
if(j>=5-i && j<=3+i)
{
System.out.print("*");
}
else
{
System.out.print(" ");
}
}
System.out.println();
}
}
}