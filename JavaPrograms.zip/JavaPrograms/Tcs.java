import java.util.Scanner;

public class Tcs {
    public static void main(String[] args) {
        System.out.print("enter the array size=");
        int count = 0, temp = 0;
        Scanner SC = new Scanner(System.in);
        int size = SC.nextInt();
        int arr[] = new int[100];
        for (int i = 0; i < size; i++) {
            arr[i] = SC.nextInt();
        }
        for (int i = 0; i < size; i++) {
            for (int j = i; j < size; j++) {
                if (arr[j] < arr[j + 1]) {
                    temp = arr[j + 1];

                }

            }
            System.out.println("ydgsdhb" + temp);

        }

    }

}
