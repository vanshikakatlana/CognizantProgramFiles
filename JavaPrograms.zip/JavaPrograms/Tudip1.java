import java.util.Scanner;

public class Tudip1 {
    public static void main(String[] args) {

        int arr[] = new int[100];
        int temp = 0;
        System.out.print("enter the array size=");
        Scanner SC = new Scanner(System.in);
        int n = SC.nextInt();
        for (int i = 0; i < n; i++) {
            arr[i] = SC.nextInt();

        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;

                }
            }

        }
        System.out.println("third largest number" + arr[2]);

    }

}
