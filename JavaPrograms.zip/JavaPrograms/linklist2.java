public class linklist2 {
    int data;
    linklist2 next;

    linklist2(int data) {
        this.data = data;

    }

    public static void main(String[] args) {
        linklist2 l1 = new linklist2(3);
        linklist2 l2 = new linklist2(6);

        linklist2 l3 = new linklist2(9);

        linklist2 l4 = new linklist2(12);
        l1.next = l2;
        l2.next = l3;
        l3.next = l4;

        linklist2 temp = l1;
        // for (int i = 1; i <= 4; i++) {
        // System.out.print(temp.data + " ");
        // temp = temp.next;
        // }
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

    }
}
