import java.util.*;
class Destructor
{
public void fin()
{
System.out.println("destroy the destructor");
}
public static void main(String []args)
{
Destructor d1=new Destructor();
d1.fin();
d1=null;
d1.fin();
}
}
