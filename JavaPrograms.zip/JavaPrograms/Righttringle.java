import java.util.*;
class Righttringle
{
public static void main(String []args)
{
int i,j;
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
for(i=1;i<=a;i++)
{
for(j=1;j<=a;j++)
{
if(j<=i)
{
System.out.print("*");
}
else
{
System.out.print(" ");
}
}
System.out.println();
}
}
}


