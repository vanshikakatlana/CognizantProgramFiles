interface A {
    void show();
}

interface B extends A {
    void display();

    int a = 10;

    default void f1() {
        System.out.println("gfdgewfd");
    }
}

class Example1 implements A, B {
    public void show() {
        System.out.println("dghejdhjekd");
    }

    public void display() {
        System.out.println("gfdygewud");
    }

    public static void main(String[] args) {
        Example1 a1 = new Example1();
        a1.show();
        a1.display();
        a1.display();

    }

}
