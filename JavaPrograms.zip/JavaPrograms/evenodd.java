import java.util.*;
public class evenodd
{
public static void main(String[]args)
{
Scanner Sc=new Scanner(System.in);
int n=Sc.nextInt();
if(n%2==0)
{
System.out.println("number is even");
}
else
{
System.out.println("%d number is odd "+n);
}
}
}