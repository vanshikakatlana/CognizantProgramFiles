import javax.swing.*;
class Login
{
public static void main(String [] args)
{
JFrame j1=new JFrame();
j1.setSize(400,300);
j1.setVisible(true);
j1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}