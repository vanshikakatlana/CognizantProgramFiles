public class TcsSubarray {
    public static void main(String[] args) {
        int arr[] = { 1, 1, 2 };
        int sum = 0;
        int tagert = 2;
        System.out.println("The subarrays are-");

        // For loop for start index
        for (int i = 0; i < arr.length; i++)

            // For loop for end index
            for (int j = i; j < arr.length; j++) {

                // For loop to print subarray elements
                for (int k = i; k <= j; k++) {
                    sum = sum + arr[k];
                    if (sum == tagert) {
                        System.out.print(arr[k]);
                        System.out.println("");
                    }

                }

            }
    }
}
