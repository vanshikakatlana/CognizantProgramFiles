import java.util.Scanner;

public class Tcs2 {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the hours=");
        int t = SC.nextInt();
        int e[] = new int[t];
        int l[] = new int[t];
        System.out.println("enter the value of entry");
        for (int i = 0; i < t; i++) {
            e[i] = SC.nextInt();
        }
        System.out.println("enter the valve of exit");
        for (int i = 0; i < t; i++) {
            l[i] = SC.nextInt();
        }
        int sum = 0, max = 1;
        for (int i = 0; i < t; i++) {
            sum = sum + e[i] - l[i];
            if (max < sum) {
                max = sum;
            }
        }
        System.out.println("No.of guests on ship=" + max);

    }

}
