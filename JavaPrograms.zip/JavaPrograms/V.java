import java.util.*;
class V
{
public static void main(String []args)
{
TreeSet t=new TreeSet();
t.add(5);
t.add(2);
t.add(6);
t.add(10);
t.add(7);
t.add(1);
t.add(3);
t.add(8);
t.add(4);
t.add(9);
System.out.println(t);
System.out.println(t.first());
System.out.println(t.last());
System.out.println(t.headSet(5));
System.out.println(t.tailSet(5));
System.out.println(t.subSet(1,5));
System.out.println(t.comparator());
}
}