
import java.util.*;
class Searching 
{
public static void main(String[] args)
{
System.out.println("Enter the string:");
Scanner SC = new Scanner(System.in);
String s1 = SC.nextLine();
System.out.println(s1.indexOf('a'));
System.out.println(s1.lastIndexOf('a'));
System.out.println(s1.charAt(6));
System.out.println(s1.contains("vansh"));
System.out.println(s1.startsWith("d"));
System.out.println(s1.endsWith("a"));

}
}