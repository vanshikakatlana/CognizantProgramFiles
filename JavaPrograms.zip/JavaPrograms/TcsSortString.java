import java.util.Scanner;

public class TcsSortString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String s1 = SC.nextLine();
        char[] arr = s1.toCharArray();
        char temp;
        int i, j;
        for (i = 0; i < s1.length(); i++) {
            for (j = i + 1; j < s1.length(); j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }

        }
        System.out.println(new String(arr));

    }

}
