import java.util.*;
class Collection1
{
public static void main(String []args)
{
ArrayList a1=new ArrayList(5);
a1.add("A");
a1.add("B");
a1.add("C");
a1.add("D");
a1.add("Vanshika");
System.out.println(a1);
}
}