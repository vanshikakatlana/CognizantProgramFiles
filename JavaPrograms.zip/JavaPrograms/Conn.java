class ConsoleApp 
{
void fun()
{
System.out.println("jgugjh");
}
ConsoleApp ()
{
System.out.println("this is a constructor");
}
private void fun1()
{
System.out.println("this is a private method");
}
}
class Conn extends ConsoleApp 
{
void fun ()
{

super.fun();
System.out.println("dfdsfds");
}
public static void main(String[] args)
{
Conn c1 = new Conn();
c1.fun();

}
}