import java.util.*;
class Num 
{
public static void main(String []args)
{
int i;
 Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
for(i=0;i<=a;i++)
{
if (i%2==0)
{
System.out.println(i);
}
else
{
System.out.println(a);
}
}
}
}