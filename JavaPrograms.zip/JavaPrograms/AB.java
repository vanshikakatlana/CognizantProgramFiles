class A
{
    private int a;
    private int b;
    void fun1()
    {
        a=5;
        b=6;
    }
    void show()
    {
        System.out.println(a);
        System.out.println(b);       
    }
}
class B
{
    public static void main(String[] args)
    {
        A a1=new A();
        a1.show();
        a1.fun1();
    }
}