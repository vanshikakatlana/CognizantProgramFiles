import java.util.Scanner;

public class TcsStringToArray {

    public static void main(String[] args) {
        int j;
        Scanner SC = new Scanner(System.in);
        System.out.println("enter the String");
        String s1 = SC.nextLine();
        int length = s1.length();
        char[] myArr = s1.toCharArray();
        for (int i = 0; i < length; i++) {
            for (j = i + 1; j < length; j++) {
                if (myArr[i] == myArr[j]) {
                    myArr[j] = '#';
                }
            }
        }
        for (char c : myArr) {
            System.out.print(c);
        }

    }
}
