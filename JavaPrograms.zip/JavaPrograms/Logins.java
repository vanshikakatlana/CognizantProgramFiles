import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class Logins extends JFrame
{
JLabel l1,l2,l3,l4;
JTextField t1;
JPasswordField t2;
JButton b1,b2,b3;

Logins(String a)
{
super(a);
}
Logins()
{
}
void setComponents()
{

Cursor c1=new Cursor(Cursor.HAND_CURSOR);
Font f1=new Font("Time New Roman",Font.ITALIC,28);

 l1=new JLabel("Welcome to made by Vanshika website");
l1.setFont(f1);
l1.setForeground(Color.RED);
setLayout(null);
l1.setBounds(130,50,500,30);
 l2=new JLabel("USENAME:");
l2.setBounds(150,100,150,30);
 l3=new JLabel("PASSWORD:");
l3.setBounds(150,150,100,30);

b1=new JButton("Login");
b1.setCursor(c1);
b1.setForeground(Color.WHITE);
b1.setBackground(Color.BLUE);
b1.setBounds(90,220,100,30);

 b2=new JButton("Clear");
b2.setCursor(c1);
b2.setForeground(Color.WHITE);
b2.setBackground(Color.BLUE);
b2.setBounds(350,220,100,30);

t1=new JTextField();
t1.setBounds(250,100,100,30);
t2=new JPasswordField();
t2.setBounds(250,150,100,30);
 l4=new JLabel();
l4.setBounds(100,300,300,30);
b3=new JButton("Add");
b3.setCursor(c1);
b3.setForeground(Color.WHITE);
b3.setBackground(Color.BLUE);
b3.setBounds(450,280,100,30);

b1.addActionListener(new Log());
b2.addActionListener(new Clear());
b3.addActionListener(new Add());
l2.addMouseListener(new MouseL());
add(l1);
add(l2);
add(l3);
add(b1);
add(b2);
add(t1);
add(t2);
add(l4);
add(b3);
}
public static void main (String []args)
{
Logins s1=new Logins("WELCOME TO THIS WEBSITE");
s1.setSize(500,500);
s1.setVisible(true);
s1.setComponents();
s1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
class MouseL implements MouseListener
{
public void mouseClicked(MouseEvent e1)
{

}
public void  mousePressed(MouseEvent e1)
{
l2.setText("");
}
public void mouseReleased(MouseEvent e1)
{
l2.setText("USERNAME:");
}
public void mouseEntered(MouseEvent e1)
{
l2.setForeground(Color.RED);
}
 public void mouseExited(MouseEvent e1)
{
l2.setForeground(Color.BLACK);
}
}
class Log implements ActionListener
{
public void actionPerformed(ActionEvent e1)
{
String s1=t1.getText();
String s2=t2.getText();
if(s1.equals("Vanshika Katlana") && s2.equals("Vanshika@123"))
{
JOptionPane.showMessageDialog(null,"Login Successful");
l4.setText("LOGIN SUCCESSFUL");
}
else
{
JOptionPane.showMessageDialog(null,"Login Unsuccessful");
l4.setText("LOGIN UNSUCCESSFUL");
}
}
}
class Clear implements ActionListener
{
public void actionPerformed(ActionEvent e1)
{
t1.setText("");
t2.setText("");
}
}
class Add implements ActionListener
{
public void actionPerformed(ActionEvent e1)
{
try
{
int a=Integer.parseInt(t1.getText());
int b=Integer.parseInt(t2.getText());
int c=a+b;
l4.setText("Addition is "+c);
}
catch(Exception e2)
{
l4.setText("please enter the number");
}
}
}
}