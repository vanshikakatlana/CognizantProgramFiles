import java.util.*;
class Collection2
{
public static void main(String []args)
{
ArrayList a1=new ArrayList();
a1.add(22);
a1.add(23);
a1.add(25);
System.out.println(a1);
a1.add(2,24);
a1.set(0,21);
a1.get(2);
System.out.println(a1);
Iterator g1=a1.iterator();
while(g1.hasNext())
{
int a=(int)g1.next();
if(a>=24)
{
System.out.println(a);
}
}
}
}