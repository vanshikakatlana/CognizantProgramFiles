import java.util.Scanner;

public class TcsReverseString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String S1 = SC.nextLine();
        StringBuffer res = new StringBuffer();
        res.append(S1);
        res.reverse();
        int a = S1.indexOf('v', 0);
        System.out.println(res);
        System.out.println(a);

    }
}
