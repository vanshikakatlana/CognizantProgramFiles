package p2;
import p1.Setdata;
import java.util.*;
class Showdata
{
public static void main(String []arge)
{
Scanner SC=new Scanner(System.in);
int a=SC.nextInt();
int b=SC.nextInt();
Setdata s1=new Setdata();
}
} 