import java.util.*;
import java.util.Scanner;

public class TcsMap {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the array size=");
        int n = SC.nextInt();
        int i;
        int arr[] = new int[100];
        for (i = 1; i <= n; i++) {
            arr[i] = SC.nextInt();
        }
        LinkedList a1 = new LinkedList();
        for (i = 1; i <= n; i++) {
            a1.add(arr[i]);
        }

        a1.addFirst(6);
        a1.add(3, 8);
        a1.addLast(7);

        System.out.println(a1);

    }
}
