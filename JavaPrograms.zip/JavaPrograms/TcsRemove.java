import java.util.Scanner;

public class TcsRemove {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        int count = 1;
        System.out.print("enter the string=");
        String string = SC.nextLine();
        int length = string.length();
        System.out.println(length);
        int n = 0;
        char ch='0';
        char[] arr = string.toCharArray();// input=Leeetcode,output=Leetcode
        // max=e e==t newarray[n]=le count=1
        char[] newarray = new char[length];
        for (int i = 0; i < length; i++) {
            if(ch==)

            if (arr[i] == arr[i + 1]) {
                count++;
                if (count < 2) {
                    newarray[n] = arr[i + 1];
                    n++;
                }

            } else {
                newarray[n] = arr[i + 1];
                n++;
                count = 0;
            }

        }
        System.out.println(newarray[n]);

    }
}
