
/*import java.util.Scanner;

public class TcsBusStop {
    String[] BusStop = { "TH", "GA", "IC", "HA", "TE", "LU", "CA" };
    Float Path[] = new Float[] { 800.0f, 600.0f, 750.0f, 900.0f, 1400.0f, 1200.0f, 1100.0f, 1500.0f };

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        System.out.println("choose the source stop=\"TH\", \"GA\", \"IC\", \"HA\", \"TE\", \"LU\", \"CA\" ");
        String start = SC.nextLine();
        System.out.println("Start Stop=" + start);
        String end = SC.nextLine();
        System.out.println("End Stop=" + end);
        for(int i=0;i<8;i++)
        {
            if(BusStop[i]==end)
            {

            }
        }

    }
}*/
import java.util.*;

public class TcsBusStop {

    // Function to calculate the fare between two bus stops
    public static String getFare(String source, String destination) {
        // Convert source and destination to uppercase to make the comparison
        // case-insensitive
        source = source.toUpperCase();
        destination = destination.toUpperCase();

        // List of bus stops and distances between them
        String[] busStops = { "TH", "GA", "IC", "HA", "TE", "LU", "NI", "CA" };
        float[] path = { 800, 600, 750, 900, 1400, 1200, 1100, 1500 };

        // Check if the source and destination are valid bus stops
        int st = -1, ed = -1;
        for (int i = 0; i < busStops.length; i++) {
            if (source.equals(busStops[i])) {
                st = i;
            }
            if (destination.equals(busStops[i])) {
                ed = i;
            }
        }

        // If source or destination is invalid or both are the same
        if (st == -1 || ed == -1 || st == ed) {
            return "INVALID OUTPUT";
        }

        // Calculate the total distance from source to destination
        float totalDistance = 0;
        int i = st;
        while (i != ed) {
            totalDistance += path[i];
            i = (i + 1) % busStops.length; // Circular path
        }

        // Calculate fare: 5 INR per 1000 meters
        double fare = Math.ceil((totalDistance * 0.005)); // Ceil the fare to next integer value
        return fare + " INR";
    }

    public static void main(String[] args) {
        // Scanner for input
        Scanner scanner = new Scanner(System.in);

        // Read source and destination inputs
        String source = scanner.next();
        String destination = scanner.next();

        // Call the getFare function and print the result
        System.out.println(getFare(source, destination));
    }
}
