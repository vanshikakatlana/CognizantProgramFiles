import java.util.*;
class Vanshika
{
int x;
 private void fun1()
{
System.out.println("object is call");
}
void fun2()
{
System.out.println("object is not call");
}
}
class Object1
{
public static void main(String[]args)
{
System.out.println("hello");
Vanshika van=new Vanshika();
van.fun2(); 
van.x=4;
System.out.println(van.x);
}
}