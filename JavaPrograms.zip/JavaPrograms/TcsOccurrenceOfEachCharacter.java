import java.util.*;

public class TcsOccurrenceOfEachCharacter {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String string = SC.nextLine();
        int count = 1;
        Map<Character, Integer> ms = new HashMap();
        char[] arr = string.toCharArray();
        /*
         * for (int i = 0; i < string.length(); i++) {
         * for (int j = 0; j < string.length(); j++) {
         * if (i != j && arr[i] == arr[j]) {
         * count++;
         * 
         * }
         * }
         * 
         * System.out.println(arr[i] + " " + "count:" + count);
         * count = 1;
         * 
         * }
         */
        for (char ch : arr) {
            if (!ms.containsKey(ch)) {
                ms.put(ch, 1);
            } else {
                count = ms.get(ch);
                ms.put(ch, count + 1);

            }
        }
        for (char chars : ms.keySet()) {
            System.out.print(ms.get(chars) + "" + chars);
        }

    }

}
