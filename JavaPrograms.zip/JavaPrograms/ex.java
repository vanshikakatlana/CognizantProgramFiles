import java.util.Arrays;

public class ex {

    public static void main(String[] args) {
        int[] arr = { 3, 1, 9, 2, 6, 5 };
        int temp = 0, samllest = arr[0], la = arr[0], samllestIndex = 0, laIndex = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < samllest) {
                samllest = arr[i];
                samllestIndex = i;

            }
            if (arr[i] > la) {
                la = arr[i];
                laIndex = i;
            }
        }

        temp = arr[samllestIndex];
        arr[samllestIndex] = arr[laIndex];
        arr[laIndex] = temp;

        int sum = samllest + la;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == samllest || arr[i] == la) {
                arr[i] = sum;
                break;
            }
        }

    }

}
