import java.util.Scanner;

public class TcsMachine {
    public static void main(String[] args) {
        String c[] = { "Espresso Coffee", "Cappuccino Coffee", "Latte Coffee" };
        String t[] = { "Plain Tea", "Assam Tea", "Ginger Tea", "Cardamom Tea", "Masala Tea", "Lemon Tea", "Green Tea",
                "Organic Darjeeling Tea" };
        String s[] = { "Hot and Sour Soup", "Veg Corn Soup", "Tomato Soup", "Spicy Tomato Soup" };
        String b[] = { "Hot Chocolate Drink", "Badam Drink", "Badam-Pista Drink" };
        Scanner SC = new Scanner(System.in);
        System.out.print("enter the choose=");
        char ch = SC.next().charAt(0);
        System.out.print("enter the item=");
        int item = SC.nextInt();
        int i;
        if (ch == 'c') {
            for (i = 0; i < 3; i++) {
                if (item == i + 1) {
                    System.out.println("Welcome to CCD!");
                    System.out.println("Enjoy your" + " " + c[i] + "!");
                    break;
                }
            }
            if (i == 3) {
                System.out.println("INVALID OUTPUT!");
            }
        }

        if (ch == 't') {
            for (i = 0; i < 8; i++) {
                if (item == i + 1) {
                    System.out.println("Welcome to CCD!");
                    System.out.println("Enjoy your" + " " + t[i] + "!");
                    break;
                }
            }
            if (i == 8) {
                System.out.println("INVALID OUTPUT!");
            }
        }
        if (ch == 's') {
            for (i = 0; i < 4; i++) {
                if (item == i + 1) {
                    System.out.println("Welcome to CCD!");
                    System.out.println("Enjoy your" + " " + s[i] + "!");
                    break;
                }
            }
            if (i == 4) {
                System.out.println("INVALID OUTPUT!");
            }
        }
        if (ch == 'b') {
            for (i = 0; i < 3; i++) {
                if (item == i + 1) {
                    System.out.println("Welcome to CCD!");
                    System.out.println("Enjoy your" + " " + b[i] + "!");
                    break;
                }
            }
            if (i == 3) {
                System.out.println("INVALID OUTPUT!");
            }
        }

    }

}
